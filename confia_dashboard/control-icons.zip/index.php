<?php
$versao = 18;
include 'header.html';               
include 'dashboard.html';  
include 'footer.html';   
?>